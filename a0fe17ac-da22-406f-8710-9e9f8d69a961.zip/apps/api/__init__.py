"""
MailGuard OSS - API Application
"""