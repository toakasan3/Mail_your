"""
MailGuard OSS - Applications
"""